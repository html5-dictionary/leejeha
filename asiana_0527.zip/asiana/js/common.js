

$(function(){
// console.log('aa');

// gnb 호버효과 - 임시 0526
$('.gnb').on('mouseover',function(){
    $('.submenu').css('display','block');
 }).on('mouseout',function(){
    $('.submenu').css('display','none');
 });

});