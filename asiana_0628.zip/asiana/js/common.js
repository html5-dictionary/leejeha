$(function(){
// console.log('aa');

   // gnb 
   // const $gnb = $('.global_navbar');
   // // console.log($gnb_ht);
   // const $gnbList = $('.gnb_list');
   // const $li = $gnbList.find('li');

   
   // navigator share button
   $('.btn_share').toggle(function(){
      let shareList = $('.navigator .share_container').find('.shareicon_list');
      shareList.addClass('active');
   },function(){
      let shareList = $('.navigator .share_container').find('.shareicon_list');
      shareList.removeClass('active');
   });

   // footer group button
   $('.btn_group').on('click',function(){$('.grp_box').slideToggle();});



   // login tab list
   $('.tab_content .tc').hide();
   $('.tab_list li:first').addClass('active');
   $('.tab_content .tc').eq(0).show();

   $('.tab_list li').on('click',function(e){
      let thisIdx = $(this).index();
      // console.log(thisIdx);
      $('.tab_list li').removeClass('active');
      $(this).addClass('active');
      $('.tab_content .tc').hide();
      $('.tab_content .tc').eq(thisIdx).show();
   });

   // $('.btn_close').on('click',function(){
   //    $('.popup_layer').addClass('active');
   // });



});